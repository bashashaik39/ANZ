package com.reciepe.demo2.Reciepedemo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reciepedemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(Reciepedemo2Application.class, args);
	}

}
